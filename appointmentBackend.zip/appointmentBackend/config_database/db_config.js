const sqlite = require('sqlite3').verbose();

const dbPath = 'appointment.db';

const db_connexion = new sqlite.Database(dbPath, (err) => {
    if (err) {
        console.error('Erreur lors de la connexion à la base de données :', err.message);
    } else {
        console.log('Connecté à la base de données SQLite');
    }
});

module.exports = db_connexion;
