export const vendeurs = `
    CREATE TABLE IF NOT EXISTS vendeurs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom_vendeur TEXT NOT NULL,
    )
`;
export const acheteurs = `
    CREATE TABLE IF NOT EXISTS acheteurs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom_acheteur TEXT NOT NULL,
        nom_entreprise TEXT NOT NULL
    )
`;
export const rendezvous = `
    CREATE TABLE IF NOT EXISTS rendezvous (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        titre TEXT NOT NULL,
        type TEXT NOT NULL,
        lieu TEXT NOT NULL,
        hote INTEGER,
        client INTEGER,
        heureDebut DATETIME NOT NULL,
        heureFin DATETIME NOT NULL,
        FOREIGN KEY (hote) REFERENCES vendeurs(id),
        FOREIGN KEY (client) REFERENCES acheteurs(id)
    )
`;