import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './App'
import AddAppointment from './pages/Appointment/AddAppointment'

const RouteApp: React.FC = () => (
	<Router>
		<Routes>
			<Route path="/" element={<Home />} />
			<Route path="/add_appointment" element={<AddAppointment />} />
		</Routes>
	</Router>
);

export default RouteApp;