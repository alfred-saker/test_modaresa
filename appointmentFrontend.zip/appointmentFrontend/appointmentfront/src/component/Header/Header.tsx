import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import logo from './images/logo_modaresa.svg'
import './Header.css';

const Header: React.FC = () => {
  return (
    <header>
      <div className='container'>
        <nav>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><a href="#">Our solutions</a></li>
            <li><a href="#">About us</a></li>
            <img src={logo} alt="Logo modaresa" className='logo'/>
            <li><a href="#" className='specialLink'>Log in</a></li>
            <li><a href="#" className='special_Link'>BOOK A DEMO NOW</a></li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
