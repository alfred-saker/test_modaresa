
import React from 'react';
import logo from './images/logo_modaresa.svg'
import './Footer.css';

const Footer: React.FC = () => {
  return (
    <footer>
      <p>copyright</p>
    </footer>
  );
};

export default Footer;
