import React from 'react';
import { Form, Button } from 'react-bootstrap';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import logo from './images/logo_modaresa.svg'
import Header from '../../component/Header/Header'
import Footer from '../../component/Footer/Footer'
import ButtonLink from '../../component/Button/ButtonLink';
import './Appointment.css';

const AddAppointment: React.FC = () => {
  const handleClick = () => {
  }

  return (
    <div className='main_appointment'>
      <Header />
      <div className='title-add'>
        <h2>Add Appointment</h2>
        <Link to="/">All Appointment</Link> 
      </div>
      <div className='separate-barre'></div>

      <div className='form-add'>
        <Form>
          <div className='form_div_text'>
            <Form.Label>Title </Form.Label>
            <Form.Control type="text" placeholder="Title appointment" />
          </div>
          <div className='form_div_text'>
            <Form.Label>location</Form.Label>
            <Form.Control type="text" placeholder="Location appointment" />
          </div>
          <div className='form_div_time'>
            <Form.Label>Start time</Form.Label>
            <Form.Control type="time"/>
          </div>
          <div className='form_div_time'>
            <Form.Label>End time</Form.Label>
            <Form.Control type="time"/>
          </div>
          <div className='form_div_select'>
            <Form.Select>
              <option>Choose the salers</option>
              <option>One</option>
              <option>Two</option>
              <option>Three</option>
            </Form.Select>
          </div>
          <div className='form_div_select'>
            <Form.Select>
              <option>Choose the Buyers</option>
              <option>One</option>
              <option>Two</option>
              <option>Three</option>
            </Form.Select>
          </div>
          <div className='form_div_button'>
            <ButtonLink  label="Add Appointment" onClick={handleClick}/>
          </div>
          </Form>
          {/* <div className='separate-barre'></div>
        <Footer /> */}
      </div>
    </div>
    
  );
};

export default AddAppointment;