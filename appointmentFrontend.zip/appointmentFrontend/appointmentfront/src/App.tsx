import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';

import Header from '../src/component/Header/Header';
import Footer from './component/Footer/Footer';
import ButtonLink from './component/Button/ButtonLink';
import AddAppointment from './pages/Appointment/AddAppointment';


import './Css/reset.css';
import './Css/App.css';


const Home: React.FC = () => {
  const handleClick = () => {
    // Logique à exécuter lors du clic sur le bouton
  };
  
  return (
      // <div className='main'>
      <main className="container"> 
        <Header />
          <div className="title_card_home">
            <h2>Appointments</h2>
            <Link to="/add_appointment">ADD APPOINTMENT</Link> 
          </div>
          <div className='separate-barre'></div>
          <div className='card_main'>
            <div className='card'>
              <h1>Title Appointment</h1>
              <p>Loation : Paris, France</p>
              <p>Sales : SOCAVER</p>
              <p>Buyers : SOCAVER</p>
              <p>Start-time : 14h00</p>
              <p>End-time : 16h00</p>
              <ButtonLink label="Mon Bouton" onClick={handleClick} />
            </div>
            <div className='card'>
              <h1>Title Appointment</h1>
              <p>Start-time : 14h00</p>
              <p>End-time : 16h00</p>
              <p>Lieu : Paris, France</p>
              <p>Seller : SOCAVER</p>
              <p>Customer : SOCAVER</p>
              <ButtonLink label="Mon Bouton" onClick={handleClick} />
            </div>
            <div className='card'>
              <h1>Title Appointment</h1>
              <p>Start-time : 14h00</p>
              <p>End-time : 16h00</p>
              <p>Lieu : Paris, France</p>
              <p>Seller : SOCAVER</p>
              <p>Customer : SOCAVER</p>
              <ButtonLink label="Mon Bouton" onClick={handleClick} />
            </div>
            <div className='card'>
              <h1>Title Appointment</h1>
              <p>Start-time : 14h00</p>
              <p>End-time : 16h00</p>
              <p>Lieu : Paris, France</p>
              <p>Seller : SOCAVER</p>
              <p>Customer : SOCAVER</p>
              <ButtonLink label="Mon Bouton" onClick={handleClick} />
            </div>
            <div className='card'>
              <h1>Title Appointment</h1>
              <p>Start-time : 14h00</p>
              <p>End-time : 16h00</p>
              <p>Lieu : Paris, France</p>
              <p>Seller : SOCAVER</p>
              <p>Customer : SOCAVER</p>
              <ButtonLink label="Mon Bouton" onClick={handleClick} />
            </div>
            <div className='card'>
              <h1>Title Appointment</h1>
              <p>Start-time : 14h00</p>
              <p>End-time : 16h00</p>
              <p>Lieu : Paris, France</p>
              <p>Seller : SOCAVER</p>
              <p>Customer : SOCAVER</p>
              <ButtonLink label="Mon Bouton" onClick={handleClick} />
            </div>
          </div>

          <div className='separate-barre'></div>
          <Footer />
      </main>
      // </div>
  );
};
const App: React.FC = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/add_appointment" element={<AddAppointment />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;

